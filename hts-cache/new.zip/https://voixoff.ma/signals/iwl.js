<!DOCTYPE html>
<html lang="en" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>عفوًا! حدث خطأ ما. يرجى المحاولة مرة أخرى</title>

    
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@200;300;400;500;600;700;800;900&display=swap" rel="stylesheet">

    
    <style>
        :root {
            --color-primary-h: 45;
            --color-primary-s: 87%;
            --color-primary-l: 61%;
        }
        html {
            font-family: Sole Sans Extended Extra Bold, sans-serif !important;
        }
    </style>

    
    <link href="https://voixoff.ma/public/css/app.css" rel="stylesheet">
    <link href="https://voixoff.ma/public/css/style.css" rel="stylesheet">

</head>
<body class="h-full">
    
    <div class="bg-gray-50 min-h-full px-4 py-16 sm:px-6 sm:py-24 md:grid md:place-items-center lg:px-8">
        <div class="max-w-max mx-auto">
            <main class="sm:flex">
                <p class="text-4xl font-extrabold text-primary-600 sm:text-5xl">404</p>
                <div class="sm:ml-6">
                    <div class="sm:border-l sm:border-gray-200 sm:pl-6">
                        <h1 class="text-2xl font-extrabold text-gray-900 sm:text-3xl uppercase tracking-widest">
                            الصفحة غير موجودة                        </h1>
                        <p class="mt-1 text-base text-gray-500">
                            يرجى التحقق من عنوان URL في شريط العنوان والمحاولة مرة أخرى                        </p>
                    </div>
                    <div class="mt-10 flex space-x-3 sm:border-l sm:border-transparent sm:pl-6">
                        <a href="https://voixoff.ma" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md shadow-sm text-white bg-primary-600 hover:bg-primary-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-600">
                            العودة إلى الصفحة الرئيسية    
                        </a>
                        <a href="https://voixoff.ma/help/contact" class="inline-flex items-center px-4 py-2 border border-transparent text-sm font-medium rounded-md text-primary-700 bg-indigo-100 hover:bg-indigo-200 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-primary-600">
                            تواصل معنا    
                        </a>
                    </div>
                </div>
            </main>
        </div>
    </div>

</body>
</html>
